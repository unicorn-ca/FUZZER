import requests
from hypothesis import given, assume, settings,HealthCheck,Verbosity, strategies as st
from datetime import timedelta

# add path vscode plugin
def read_payload():
    with open("FUZZDB_Postgres_Enumeration.txt",'r') as infile:
        blns = infile.readlines()
    return blns

def handler(event, context):
    # falsification set not provided, need to produce generate for sql
    # very basic example for rest api from https://hypothesis.readthedocs.io/en/latest/examples.html
    @settings(verbosity=Verbosity.verbose,deadline=timedelta(seconds=100),max_examples=15)
    @given(st.sampled_from(read_payload()))
    def fuzz(s):
        #params = {'vuln-string': vuln}
        response = requests.get("https://faw4qzwyxg.execute-api.us-east-2.amazonaws.com/dev",params={"vuln-string":s})
        print(response.json())
        if response.status_code == 200:
            assert(response.json()['result']=="None")
        # enumeration attack assert null response for now
    fuzz()